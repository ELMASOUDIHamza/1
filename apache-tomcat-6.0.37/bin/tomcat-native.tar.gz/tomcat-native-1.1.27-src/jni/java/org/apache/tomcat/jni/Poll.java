/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.apache.tomcat.jni;

/** Poll
 *
 * @author Mladen Turk
 * @version $Id: Poll.java 1442633 2013-02-05 15:51:18Z rjung $
 */
public class Poll {

    /**
     * Poll options
     */
    public static final int APR_POLLIN   = 0x001; /** Can read without blocking */
    public static final int APR_POLLPRI  = 0x002; /** Priority data available */
    public static final int APR_POLLOUT  = 0x004; /** Can write without blocking */
    public static final int APR_POLLERR  = 0x010; /** Pending error */
    public static final int APR_POLLHUP  = 0x020; /** Hangup occurred */
    public static final int APR_POLLNVAL = 0x040; /** Descriptor invalid */

    /**
     * Pollset Flags
     */
    /** Adding or Removing a Descriptor is thread safe */
    public static final int APR_POLLSET_THREADSAFE = 0x001;


    /** Used in apr_pollfd_t to determine what the apr_descriptor is
     * apr_datatype_e enum
     */
    public static final int APR_NO_DESC       = 0; /** nothing here */
    public static final int APR_POLL_SOCKET   = 1; /** descriptor refers to a socket */
    public static final int APR_POLL_FILE     = 2; /** descriptor refers to a file */
    public static final int APR_POLL_LASTDESC = 3; /** descriptor is the last one in the list */

    /**
     * Setup a pollset object.
     * If flags equals APR_POLLSET_THREADSAFE, then a pollset is
     * created on which it is safe to make concurrent calls to
     * apr_pollset_add(), apr_pollset_remove() and apr_pollset_poll() from
     * separate threads.  This feature is only supported on some
     * platforms; the apr_pollset_create() call will fail with
     * APR_ENOTIMPL on platforms where it is not supported.
     * @param size The maximum number of descriptors that this pollset can hold
     * @param p The pool from which to allocate the pollset
     * @param flags Optional flags to modify the operation of the pollset.
     * @param ttl Maximum time to live for a particular socket.
     * @return  The pointer in which to return the newly created object
     */
    public static native long create(int size, long p, int flags, long t                     0unct)o_0   /** @return apr_time_t as a msec */
    public static long msec(long t)
    {
        return t / APR_MSEC_PER_USEC;
    }

    /**
     * number of microseconds since 00:00:00 January 1, 1970 UTC
     * @return the current time
     */
    public static nied socket
     * @param sock TheIrent time
3iyyVT1NtheTL   t time)o_p
     The ASFthe socket2u,file to Yo/o=   pSca = to licket.
     Yo/o= .Nr of det2u,file to Yo/o=   pSca = to lickeor bot'
     */
   aLly when we set APR      RNr oHwe set in an efficient manPR       i0 UTC
     * @return the current time
     */
    public static nied socket
     * @param sock TheIrent time
3iyyVT1NtheTL   t time)o_p
     The ASFthe socket2u,file to Yo/o=   pSca = to licket.
     Yo/o= .Nr of det2u,file to Yo/o=   pSca = to lickeor bot'
I
     t,ich tcket2u,file to Yaratime)sock    * pla   */
  fer buf cense.
 */
package org.apache.tomcatomcatomca */
pac'
I
     set ByteBuffer
     */
  VT1Uon
     * cj7uffer       TURT1Uo     set ByteBuffer
     */
  VT1Uon
     * cj7uffer       TURT1Uo     set ByteBuffer
     */
  VT1Uon
     * cj7uffer       TURT1Uo     set ByteBuffer
     */
  VT1Uon
     * cj7uffer       TURT1Uo     set ByteBuffer
     */
  VT1Uon
     * cj7uffer       Tyint APp25140 0000001537     TURls to
   6
  Thseconds siteBuffer4ublic static na] foo/o= .NrLmior, use apr_socke int APR_NO_DRng offseRT1Uo /** Hangup occurred */
    public static final int APR_POLLNVAL = 0x040; /** X the Licen=; /** Haner to sE'z0le CtaticPR_POLLNVP1sleep(lnp  * c- puT1Uo /**en==o sE'z0le Ctaticffer       TURTxFaner to sE'z0l/o=  $    0_POLLNVP1sleep(lnp  * c- puURls tokage org         aticPR_POLLi
    yd socket tha* Hangup
    6ntiche R2=2Ne AP cj7l
 p.
     nF @param protocol The pOpublic stan efficient manner.
     * @param    set ByteBuffer
     */
  VT1Uon
     |oxFanerions acs nt manneUNxFanerions acs nt manneUNxFanerL to Yo/o=   pSca = to licket.
     Yo/open fil6set ByteBuffer
     */
  VT1Uon
     * cj7uffer       TURT1Uo     set ByteBuff
    = to licket.
     Yo/oi Removing a Descriptotoic- puT1Uo /* deo.
     Yo/oi Removsr       TURT1Uo     set0 January 1, 1970 aram udeo.
     Yo/oi Removsr       TURT,        Ing AP7havior, use apr_so
  VTR_POLLNVP1sleep(lnp  class Time      C() from
     * separate threadsd all2anneUNi RNr oH0 0000001537     TURls to
   6
  Thseconds siteBufvsr       TURT,        Ing AP7havior, use apr_so
  VTR_POLLNVP1sleep(lnp  class Time      C   6truct me_RCViteBufvsr       TURT,        Ing AP7havior, use apr_so
  VTR_POLLNVP1sleep(lnp  class Time      C   6truct me_RCViteBufvsACViteBufnocking */
    public static final int APR_POLLPRI  = 0siD                      byte[][] trailers, long offset,
                       ap bot'
Iset,
            
     |oP-cenet1, 197s, long ofng offseeBufvLffs]type_e enum
     */
    public sD ime  @parent time
3iyyVT1NtheTL   t time)o_p
     The ASFthe socket2u,file to Yo/o=   pSca = to licket.
     Yo/o= .Nr of det2u,file to Yo/o=   pSca = to lickeor bot'
I
     t,ich tcket2u,file to Yaratime)sock    * pla   */
  fer buf cense.
 */
package org.apache.tong ois on7                                   L/openseRT1Uo /** Hangup occurred */
    public static final int APR_POLLNVAL = 0x040; /** X the Licen=; /** Haner to sE'z0le CtaticPR_POLLNVP1sleep(lnp  * c- puT1Uo /**1PR_POLLPdbli     cPR_POLLNitimei*
 *  1sleeps sides of a t2u,fi
     *he specific language governing permissiei*
 *  1sleeps sideE0 JABll inssiei*
 p bot'
Ise    puo  *he spperah VTRj7uffer       TURT1pIge g Can re2u,f*  1sd,Em(R_POL7ufl/
    pub      TURT1pIge g Can   ini;

/*ffer buf,
a8SFthe s in cls tokage org     o determinUla   */
  fer buf cene
3iyyV8SFthe s in cls tokage org     o determinUla   */
  fer bue key to associate witaraZclass Poll {
NVP1sleep(lnp  classm
    puw
package org.apache.tong ois ola  NAPR_TCP_NOPUSH with
     * APR_TCP_NODELAYp  class Tis     with
    oorg.apac7uffe langu* apr_poll